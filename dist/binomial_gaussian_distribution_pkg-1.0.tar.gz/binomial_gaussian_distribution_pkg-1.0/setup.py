from setuptools import setup

setup(name='binomial_gaussian_distribution_pkg',
      version='1.0',
      description='Binomial and Gaussian Distribution',
      packages=['binomial_gaussian_distribution_pkg'],
      author="John Tian",
      author_email="johntian2014@gmail.com",
      zip_safe=False)
